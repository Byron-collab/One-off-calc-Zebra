# Notion Calculator (One-Off Jobs)

This is a single-file HTML calculator you can host on GitHub Pages and embed in Notion.

- Open `index.html` locally to test.
- Publish to GitHub Pages to get a public URL.
